from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

HOME = InlineKeyboardButton(text="🏠 Главное меню", callback_data="home")
SEARCH = InlineKeyboardButton(text="🔎 Поиск фильма", callback_data="search")
SEARCH_AGAIN = InlineKeyboardButton(text="🔎 Новый поиск", callback_data="search")
CANCEL = InlineKeyboardButton(text="✖️ Отменить поиск", callback_data="cancel")


def menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🎬 Каталог фильмов", callback_data="catalog")],
            [SEARCH],
            [InlineKeyboardButton(text="ℹ️ О проекте", callback_data="about")],
        ]
    )
