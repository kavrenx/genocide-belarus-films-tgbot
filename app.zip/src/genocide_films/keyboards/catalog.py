from collections.abc import Callable
from typing import Annotated

from aiogram.filters.callback_data import CallbackData
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from pydantic import Field, StringConstraints

from genocide_films.keyboards.main import HOME, SEARCH_AGAIN
from genocide_films.models.film import Age, Film, FilmId, FilmType
from genocide_films.services.catalog import FilmPage

PageIndex = Annotated[int, Field(ge=0, le=999_999_999)]
SearchKey = Annotated[str, StringConstraints(pattern=r"^[0-9a-f]{12}$")]


class AgeChoice(CallbackData, prefix="age"):
    age: Age


class CatalogPage(CallbackData, prefix="list"):
    age: Age
    kind: FilmType
    page: PageIndex = 0


class CatalogCard(CallbackData, prefix="film"):
    age: Age
    kind: FilmType
    page: PageIndex
    film_id: FilmId
    part: PageIndex = 0


class SearchPage(CallbackData, prefix="sp"):
    key: SearchKey
    page: PageIndex = 0


class SearchCard(CallbackData, prefix="sf"):
    key: SearchKey
    page: PageIndex
    film_id: FilmId
    part: PageIndex = 0


def button(text: str, action: CallbackData | str) -> InlineKeyboardButton:
    return InlineKeyboardButton(
        text=text, callback_data=action if isinstance(action, str) else action.pack()
    )


def ages() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[button(age.label, AgeChoice(age=age))] for age in Age] + [[HOME]]
    )


def types(age: Age, available: tuple[FilmType, ...]) -> InlineKeyboardMarkup:
    kinds = (FilmType.FEATURE, FilmType.DOCUMENTARY)
    if FilmType.ANIMATION in available:
        kinds += (FilmType.ANIMATION,)
    rows = [[button(kind.label, CatalogPage(age=age, kind=kind))] for kind in kinds]
    return InlineKeyboardMarkup(inline_keyboard=[*rows, [button("◀️ Назад", "catalog")], [HOME]])


def films(
    page: FilmPage,
    open_film: Callable[[Film], CallbackData],
    open_page: Callable[[int], CallbackData],
    back: CallbackData | None = None,
) -> InlineKeyboardMarkup:
    rows = [
        [button(f"{film.title} ({film.year})" if film.year else film.title, open_film(film))]
        for film in page.items
    ]
    arrows = []
    if page.index > 0:
        arrows.append(button("⬅️ Предыдущая", open_page(page.index - 1)))
    if page.index + 1 < page.total:
        arrows.append(button("Следующая ➡️", open_page(page.index + 1)))
    if arrows:
        rows.append(arrows)
    rows.append([button("◀️ Назад", back)] if back else [SEARCH_AGAIN])
    rows.append([HOME])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def card(
    back: CallbackData,
    part: int = 0,
    total: int = 1,
    open_part: Callable[[int], CallbackData] | None = None,
) -> InlineKeyboardMarkup:
    arrows = []
    if open_part and part > 0:
        arrows.append(button("⬅️ Описание", open_part(part - 1)))
    if open_part and part + 1 < total:
        arrows.append(button("Описание ➡️", open_part(part + 1)))
    rows = [arrows] if arrows else []
    return InlineKeyboardMarkup(inline_keyboard=[*rows, [button("◀️ Назад", back)], [HOME]])
