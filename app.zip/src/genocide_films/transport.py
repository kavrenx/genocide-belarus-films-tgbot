from aiogram.client.session.aiohttp import AiohttpSession
from aiohttp import ClientSession


class EnvironmentProxySession(AiohttpSession):
    """Использует прокси окружения и системное хранилище доверенных CA."""

    async def create_session(self) -> ClientSession:
        if self._session is None or self._session.closed:
            self._session = ClientSession(trust_env=True)
        return self._session
