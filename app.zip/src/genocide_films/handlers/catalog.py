from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery

from genocide_films.handlers.navigation import film_art, show
from genocide_films.keyboards import catalog as keyboard
from genocide_films.keyboards.catalog import AgeChoice, CatalogCard, CatalogPage
from genocide_films.services.catalog import Catalog, paginate
from genocide_films.utils.text import film_card


async def catalog_menu(query: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await show(
        query,
        "<b>Каталог фильмов</b>\n\nВыберите рекомендованную возрастную группу.",
        keyboard.ages(),
        "welcome",
    )


async def select_age(query: CallbackQuery, callback_data: AgeChoice, catalog: Catalog) -> None:
    age = callback_data.age
    available = catalog.types(age)
    prompt = "Выберите тип кино." if available else "В этой группе пока нет фильмов."
    await show(
        query, f"<b>{age.label}</b>\n\n{prompt}", keyboard.types(age, available), f"age-{age}"
    )


async def select_type(query: CallbackQuery, callback_data: CatalogPage, catalog: Catalog) -> None:
    age, kind = callback_data.age, callback_data.kind
    page = paginate(catalog.list_films(age, kind), callback_data.page)
    title = f"<b>{kind.label}</b>\n{age.label}"
    title += f" · {page.label}" if page.items else "\n\nВ этом разделе пока нет фильмов."
    markup = keyboard.films(
        page,
        lambda film: CatalogCard(age=age, kind=kind, page=page.index, film_id=film.id),
        lambda index: CatalogPage(age=age, kind=kind, page=index),
        AgeChoice(age=age),
    )
    await show(query, title, markup, f"age-{age}")


async def select_film(query: CallbackQuery, callback_data: CatalogCard, catalog: Catalog) -> None:
    age, kind = callback_data.age, callback_data.kind
    back = CatalogPage(age=age, kind=kind, page=callback_data.page)
    film = catalog.get(callback_data.film_id)
    if film is None or film.age != age or film.kind != kind:
        await show(query, "Карточка больше недоступна.", keyboard.card(back))
        return
    text, part, total = film_card(film, callback_data.part, catalog.shares_description(film))
    markup = keyboard.card(
        back, part, total, lambda index: callback_data.model_copy(update={"part": index})
    )
    await show(query, text, markup, film_art(film))


def create_router() -> Router:
    router = Router(name="catalog")
    router.callback_query.register(catalog_menu, F.data == "catalog")
    router.callback_query.register(select_age, AgeChoice.filter())
    router.callback_query.register(select_type, CatalogPage.filter())
    router.callback_query.register(select_film, CatalogCard.filter())
    return router
