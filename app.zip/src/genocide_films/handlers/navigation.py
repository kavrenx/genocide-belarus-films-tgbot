import logging
from pathlib import Path

from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.types import CallbackQuery, FSInputFile, InlineKeyboardMarkup, InputMediaPhoto, Message

from genocide_films.models.film import Film

logger = logging.getLogger(__name__)
ASSETS = Path(__file__).resolve().parents[1] / "assets"
ILLUSTRATION = "\n\n<i>Иллюстрация</i>"


def film_art(film: Film) -> str:
    art = f"film-{film.id}"
    return art if (ASSETS / f"{art}.jpg").is_file() else f"kind-{film.kind}"


def photo(art: str) -> FSInputFile:
    return FSInputFile(ASSETS / f"{art}.jpg")


async def send(
    message: Message,
    text: str,
    markup: InlineKeyboardMarkup,
    art: str | None = None,
) -> None:
    if art:
        try:
            await message.answer_photo(
                photo(art), caption=text + ILLUSTRATION, parse_mode="HTML", reply_markup=markup
            )
            return
        except (OSError, TelegramAPIError) as error:
            logger.warning("Иллюстрация недоступна (%s).", type(error).__name__)
    await message.answer(text, parse_mode="HTML", reply_markup=markup)


async def show(
    query: CallbackQuery,
    text: str,
    markup: InlineKeyboardMarkup,
    art: str | None = None,
) -> None:
    await query.answer()
    original = query.message
    if isinstance(original, Message):
        if art:
            try:
                media = InputMediaPhoto(
                    media=photo(art), caption=text + ILLUSTRATION, parse_mode="HTML"
                )
                await original.edit_media(media, reply_markup=markup)
                return
            except (OSError, TelegramAPIError) as error:
                if isinstance(error, TelegramBadRequest) and "message is not modified" in str(
                    error
                ):
                    return
                logger.warning("Иллюстрация недоступна (%s).", type(error).__name__)
        if not original.photo:
            try:
                await original.edit_text(text, parse_mode="HTML", reply_markup=markup)
                return
            except TelegramBadRequest as error:
                reason = error.message.lower()
                if "message is not modified" in reason:
                    return
                if not any(
                    detail in reason
                    for detail in ("message to edit not found", "message can't be edited")
                ):
                    raise
        await original.answer(text, parse_mode="HTML", reply_markup=markup)
        try:
            await original.delete()
        except TelegramAPIError:
            logger.info("Предыдущее сообщение больше недоступно для удаления.")
    elif original is not None:
        await query.bot.send_message(original.chat.id, text, parse_mode="HTML", reply_markup=markup)
