from secrets import token_hex

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message

from genocide_films.handlers.navigation import film_art, send, show
from genocide_films.handlers.start import WELCOME
from genocide_films.keyboards import catalog as keyboard
from genocide_films.keyboards.catalog import SearchCard, SearchPage
from genocide_films.keyboards.main import CANCEL, HOME, SEARCH_AGAIN, menu
from genocide_films.models.film import Film
from genocide_films.services.catalog import Catalog, paginate
from genocide_films.services.search import FilmSearch
from genocide_films.utils.text import film_card

PROMPT = "🔎 Введите название фильма или его часть."
INPUT_BUTTONS = InlineKeyboardMarkup(inline_keyboard=[[CANCEL], [HOME]])
RETRY_BUTTONS = InlineKeyboardMarkup(inline_keyboard=[[SEARCH_AGAIN], [HOME]])
EXPIRED = "Эти результаты уже недоступны. Начните новый поиск."


class Search(StatesGroup):
    waiting = State()


async def begin(state: FSMContext) -> None:
    await state.clear()
    await state.set_state(Search.waiting)


async def search_command(message: Message, state: FSMContext) -> None:
    await begin(state)
    await send(message, PROMPT, INPUT_BUTTONS)


async def search_button(query: CallbackQuery, state: FSMContext) -> None:
    await begin(state)
    await show(query, PROMPT, INPUT_BUTTONS)


async def cancel_command(message: Message, state: FSMContext) -> None:
    await state.clear()
    await send(message, WELCOME, menu(), "welcome")


async def cancel_button(query: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await show(query, WELCOME, menu(), "welcome")


def results(films: tuple[Film, ...], key: str, index: int) -> tuple[str, InlineKeyboardMarkup]:
    page = paginate(films, index)
    heading = f"<b>Результаты поиска</b>\nНайдено: {len(films)} · {page.label}"
    return heading, keyboard.films(
        page,
        lambda film: SearchCard(key=key, page=page.index, film_id=film.id),
        lambda next_page: SearchPage(key=key, page=next_page),
    )


async def search_text(message: Message, state: FSMContext, film_search: FilmSearch) -> None:
    films = film_search.find(message.text or "")
    if not films:
        await send(
            message,
            "Фильмы не найдены. Попробуйте ввести другое название или его часть.",
            INPUT_BUTTONS,
        )
        return

    key = token_hex(6)
    await state.set_data({"key": key, "film_ids": [film.id for film in films]})
    await state.set_state(None)
    text, markup = results(films, key, 0)
    await send(message, text, markup)


async def search_nontext(message: Message) -> None:
    await send(message, PROMPT, INPUT_BUTTONS)


async def result_ids(state: FSMContext, key: str) -> tuple[str, ...]:
    data = await state.get_data()
    return tuple(data["film_ids"]) if data.get("key") == key else ()


async def search_page(
    query: CallbackQuery, callback_data: SearchPage, state: FSMContext, catalog: Catalog
) -> None:
    ids = await result_ids(state, callback_data.key)
    films = tuple(film for film_id in ids if (film := catalog.get(film_id)) is not None)
    if not films:
        await show(query, EXPIRED, RETRY_BUTTONS)
        return
    text, markup = results(films, callback_data.key, callback_data.page)
    await show(query, text, markup)


async def search_card(
    query: CallbackQuery, callback_data: SearchCard, state: FSMContext, catalog: Catalog
) -> None:
    ids = await result_ids(state, callback_data.key)
    if not ids:
        await show(query, EXPIRED, RETRY_BUTTONS)
        return
    back = SearchPage(key=callback_data.key, page=callback_data.page)
    film = catalog.get(callback_data.film_id) if callback_data.film_id in ids else None
    if film is None:
        await show(query, "Карточка больше недоступна.", keyboard.card(back))
        return
    text, part, total = film_card(film, callback_data.part, catalog.shares_description(film))
    markup = keyboard.card(
        back, part, total, lambda index: callback_data.model_copy(update={"part": index})
    )
    await show(query, text, markup, film_art(film))


def create_router() -> Router:
    router = Router(name="search")
    router.message.register(search_command, Command("search"))
    router.message.register(cancel_command, Command("cancel"))
    router.message.register(search_text, Search.waiting, F.text, ~F.text.startswith("/"))
    router.message.register(search_nontext, Search.waiting, ~F.text)
    router.callback_query.register(search_button, F.data == "search")
    router.callback_query.register(cancel_button, F.data == "cancel")
    router.callback_query.register(search_page, SearchPage.filter())
    router.callback_query.register(search_card, SearchCard.filter())
    return router
