from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from genocide_films.handlers.navigation import send, show
from genocide_films.keyboards.main import menu

WELCOME = (
    "<b>Genocide Belarus Films</b>\n\n"
    "Художественные и документальные фильмы и мультфильмы о геноциде белорусского "
    "народа, исторической памяти и событиях Великой Отечественной войны.\n\n"
    "Выберите возрастную группу в каталоге или найдите фильм по названию."
)


async def start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await send(message, WELCOME, menu(), "welcome")


async def home(query: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await show(query, WELCOME, menu(), "welcome")


def create_router() -> Router:
    router = Router(name="start")
    router.message.register(start, CommandStart())
    router.callback_query.register(home, F.data == "home")
    return router
