from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message

from genocide_films.handlers.navigation import send, show
from genocide_films.keyboards.main import HOME

ABOUT = (
    "<b>О проекте</b>\n\n"
    "Каталог помогает подобрать художественные и документальные фильмы, циклы и мультфильмы "
    "для знакомства с историей и памятью о Великой Отечественной войне.\n\n"
    "Возрастные группы отражают рекомендации составителя подборки. Официальные возрастные "
    "рейтинги определяются отдельно. Некоторые произведения затрагивают тяжёлые темы."
)
KEYBOARD = InlineKeyboardMarkup(inline_keyboard=[[HOME]])


async def help_message(message: Message, state: FSMContext) -> None:
    await state.clear()
    await send(message, ABOUT, KEYBOARD)


async def about(query: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await show(query, ABOUT, KEYBOARD)


def create_router() -> Router:
    router = Router(name="help")
    router.message.register(help_message, Command("help", "about"))
    router.callback_query.register(about, F.data == "about")
    return router
