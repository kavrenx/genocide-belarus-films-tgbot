import asyncio
import logging

from aiogram import Bot, Dispatcher, Router
from aiogram.exceptions import TelegramAPIError
from aiogram.fsm.storage.memory import MemoryStorage, SimpleEventIsolation
from aiogram.types import BotCommand, CallbackQuery, ErrorEvent, Message
from aiogram.utils.token import TokenValidationError
from pydantic import ValidationError

from genocide_films.config import Settings
from genocide_films.handlers import catalog, help, search, start
from genocide_films.handlers.navigation import show
from genocide_films.keyboards.main import menu
from genocide_films.repositories.film_repository import CatalogLoadError, FilmRepository
from genocide_films.services.catalog import Catalog
from genocide_films.services.search import FilmSearch
from genocide_films.transport import EnvironmentProxySession

logger = logging.getLogger(__name__)
ERROR_MESSAGE = "Не удалось выполнить действие. Попробуйте ещё раз или вернитесь через /start."


async def stale_button(query: CallbackQuery) -> None:
    await show(query, "Эта кнопка устарела. Выберите раздел заново.", menu())


async def update_error(event: ErrorEvent) -> bool:
    logger.warning("Ошибка при обработке обновления (%s).", type(event.exception).__name__)
    try:
        if event.update.callback_query is not None:
            query = event.update.callback_query
            if isinstance(query.message, Message):
                await query.message.answer(ERROR_MESSAGE, reply_markup=menu())
            else:
                await query.answer(ERROR_MESSAGE, show_alert=True)
        elif event.update.message is not None:
            await event.update.message.answer(ERROR_MESSAGE, reply_markup=menu())
    except TelegramAPIError as error:
        logger.warning("Не удалось отправить уведомление (%s).", type(error).__name__)
    return True


def create_dispatcher(repository: FilmRepository) -> Dispatcher:
    dispatcher = Dispatcher(
        storage=MemoryStorage(),
        events_isolation=SimpleEventIsolation(),
        catalog=Catalog(repository),
        film_search=FilmSearch(repository.films),
    )
    dispatcher.include_routers(
        start.create_router(), help.create_router(), catalog.create_router(), search.create_router()
    )
    fallback = Router(name="fallback")
    fallback.callback_query.register(stale_button)
    dispatcher.include_router(fallback)
    dispatcher.errors.register(update_error)
    return dispatcher


async def run(settings: Settings, repository: FilmRepository) -> None:
    dispatcher = create_dispatcher(repository)

    async def on_startup(bot: Bot) -> None:
        await bot.set_my_commands(
            [
                BotCommand(command="start", description="Главное меню"),
                BotCommand(command="search", description="Поиск фильма"),
                BotCommand(command="cancel", description="Отменить поиск"),
                BotCommand(command="help", description="О проекте"),
            ]
        )
        logger.info("Бот запущен. Записей в каталоге: %d.", len(repository.films))

    dispatcher.startup.register(on_startup)
    session = EnvironmentProxySession() if settings.telegram_use_env_proxy else None
    async with Bot(token=settings.bot_token.get_secret_value(), session=session) as bot:
        await dispatcher.start_polling(
            bot,
            allowed_updates=dispatcher.resolve_used_update_types(),
            close_bot_session=False,
        )


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    for name in ("aiogram.event", "aiogram.dispatcher", "aiogram.middlewares"):
        logging.getLogger(name).setLevel(logging.CRITICAL)
    try:
        settings = Settings()
        repository = FilmRepository.from_json(settings.catalog_path)
        asyncio.run(run(settings, repository))
    except (ValidationError, TokenValidationError):
        logger.error("Проверьте BOT_TOKEN в переменных окружения или в .env.")
        raise SystemExit(1) from None
    except CatalogLoadError as error:
        logger.error("%s", error)
        raise SystemExit(1) from None
    except TelegramAPIError as error:
        logger.error("Не удалось запустить обмен с Telegram (%s).", type(error).__name__)
        raise SystemExit(1) from None
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
