import unicodedata
from collections.abc import Iterable

from genocide_films.models.film import Film

PUNCTUATION = str.maketrans({"«": "", "»": "", '"': "", "–": "-", "—": "-"})


def normalize(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).casefold().replace("ё", "е")
    return " ".join(value.translate(PUNCTUATION).split())


class FilmSearch:
    def __init__(self, films: Iterable[Film]) -> None:
        self._index = tuple((normalize(film.title), film) for film in films)

    def find(self, query: str) -> tuple[Film, ...]:
        fragment = normalize(query)
        if not fragment:
            return ()
        exact, partial = [], []
        for title, film in self._index:
            if title == fragment:
                exact.append(film)
            elif fragment in title:
                partial.append(film)
        return (*exact, *partial)
