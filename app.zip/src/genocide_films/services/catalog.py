from collections.abc import Sequence
from dataclasses import dataclass

from genocide_films.models.film import Age, Film, FilmType
from genocide_films.repositories.film_repository import FilmRepository

PAGE_SIZE = 5


@dataclass(frozen=True, slots=True)
class FilmPage:
    items: tuple[Film, ...]
    index: int
    total: int

    @property
    def label(self) -> str:
        return f"Страница {self.index + 1} из {self.total}"


def paginate(films: Sequence[Film], index: int, size: int = PAGE_SIZE) -> FilmPage:
    if size < 1:
        raise ValueError("Размер страницы должен быть положительным.")
    total = max(1, (len(films) + size - 1) // size)
    index = min(max(index, 0), total - 1)
    return FilmPage(tuple(films[index * size : (index + 1) * size]), index, total)


class Catalog:
    def __init__(self, repository: FilmRepository) -> None:
        self.repository = repository

    def list_films(self, age: Age, kind: FilmType | None = None) -> tuple[Film, ...]:
        return tuple(
            film
            for film in self.repository.films
            if film.age == age and (kind is None or film.kind == kind)
        )

    def types(self, age: Age) -> tuple[FilmType, ...]:
        available = {film.kind for film in self.list_films(age)}
        return tuple(kind for kind in FilmType if kind in available)

    def get(self, film_id: str) -> Film | None:
        return self.repository.get(film_id)

    def shares_description(self, film: Film) -> bool:
        return self.repository.shares_description(film)
