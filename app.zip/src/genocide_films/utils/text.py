import re
from html import escape

from genocide_films.models.film import Film


def utf16_size(text: str) -> int:
    return len(text.encode("utf-16-le")) // 2


def split_description(text: str, budget: int) -> list[str]:
    parts = []
    start = end = used = 0
    for match in re.finditer(r"\S+|\s+", text):
        word = match.group()
        length = utf16_size(word)
        if used + length > budget and end > start:
            parts.append(text[start:end])
            start, used = end, 0
        if length <= budget:
            used += length
            end = match.end()
            continue
        for index, char in enumerate(word, start=match.start()):
            width = 2 if ord(char) > 0xFFFF else 1
            if used + width > budget:
                parts.append(text[start:index])
                start, used = index, 0
            used += width
        end = match.end()
    return [*parts, text[start:end]]


def film_card(film: Film, requested_part: int, shared: bool = False) -> tuple[str, int, int]:
    metadata = [f"Тип / жанр: {film.genre}", f"Рекомендованный возраст: {film.age.label}"]
    if film.year is not None:
        metadata.insert(0, f"Год: {film.year}")
    if shared:
        metadata.append("Описание из источника общее для нескольких произведений.")
    meta = "\n".join(metadata)

    # Запас учитывает номер части, переносы и помету под иллюстрацией.
    budget = 1024 - utf16_size(film.title + meta) - 96
    parts = split_description(film.description, budget)
    part = min(max(requested_part, 0), len(parts) - 1)
    section = f"\nОписание · {part + 1}/{len(parts)}" if len(parts) > 1 else ""
    text = f"<b>{escape(film.title)}</b>\n{escape(meta)}{section}\n\n{escape(parts[part])}"
    return text, part, len(parts)
