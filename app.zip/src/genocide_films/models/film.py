from enum import StrEnum
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, StringConstraints

FilmId = Annotated[str, StringConstraints(pattern=r"^[a-z0-9][a-z0-9_-]{0,23}$")]
Title = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=160)]
NonEmpty = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]


class Age(StrEnum):
    UNDER_10 = "u"
    AGE_10_15 = "m"
    AGE_15_17 = "s"

    @property
    def label(self) -> str:
        return {
            Age.UNDER_10: "До 10 лет",
            Age.AGE_10_15: "10–15 лет",
            Age.AGE_15_17: "15–17 лет",
        }[self]


class FilmType(StrEnum):
    FEATURE = "f"
    DOCUMENTARY = "d"
    ANIMATION = "a"

    @property
    def label(self) -> str:
        return {
            FilmType.FEATURE: "Художественные фильмы",
            FilmType.DOCUMENTARY: "Документальные фильмы",
            FilmType.ANIMATION: "Мультфильмы",
        }[self]


class Source(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    document: NonEmpty
    table: Annotated[int, Field(strict=True, ge=1)]
    row: Annotated[int, Field(strict=True, ge=2)]
    title_cell: NonEmpty


class Film(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    id: FilmId
    title: Title
    year: Annotated[int, Field(strict=True, ge=1888, le=9999)] | None = None
    age: Age
    kind: FilmType
    genre: Title
    description: NonEmpty
    source: Source
