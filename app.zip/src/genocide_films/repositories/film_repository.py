from collections import Counter
from collections.abc import Iterable
from pathlib import Path

from pydantic import TypeAdapter, ValidationError

from genocide_films.models.film import Film

FILMS = TypeAdapter(list[Film])


class CatalogLoadError(ValueError):
    pass


class FilmRepository:
    def __init__(self, films: Iterable[Film]) -> None:
        self.films = tuple(films)
        self._by_id = {film.id: film for film in self.films}
        if len(self._by_id) != len(self.films):
            raise CatalogLoadError("Идентификаторы фильмов повторяются.")
        self._source_count = Counter((film.source, film.description) for film in self.films)

    @classmethod
    def from_json(cls, path: Path) -> "FilmRepository":
        try:
            films = FILMS.validate_json(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, ValidationError) as error:
            raise CatalogLoadError("Проверьте доступность и формат JSON-каталога.") from error
        return cls(films)

    def get(self, film_id: str) -> Film | None:
        return self._by_id.get(film_id)

    def shares_description(self, film: Film) -> bool:
        return self._source_count[film.source, film.description] > 1
